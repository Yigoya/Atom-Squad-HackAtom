import React, { useState } from 'react';
import Question from './Question';
import ResultsModal from './ResultsModal';

const questions = [
  { id: 1, questionText: 'What is the capital of France?', options: ['Paris', 'London', 'Berlin', 'Madrid'], answer: 'Paris' },
  { id: 2, questionText: 'What is 2 + 2?', options: ['3', '4', '5', '6'], answer: '4' }
];

function Quiz() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswer = (option) => {
    if (option === questions[currentQuestionIndex].answer) {
      setScore(score + 1);
    }

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowResults(true);
    }
  };

  return (
    <div className="p-4">
      {!showResults ? (
        <Question
          data={questions[currentQuestionIndex]}
          handleAnswer={handleAnswer}
        />
      ) : (
        <ResultsModal score={score} total={questions.length} />
      )}
    </div>
  );
}

export default Quiz;
