import React from 'react';

function ResultsModel({ score, total }) {
  return (
    <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center bg-gray-500 bg-opacity-50">
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-xl mb-4">Quiz Completed!</h2>
        <p className="mb-4">Your score is {score} out of {total}.</p>
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          onClick={() => window.location.reload()}
        >
          Restart Quiz
        </button>
      </div>
    </div>
  );
}

export default ResultsModel;
