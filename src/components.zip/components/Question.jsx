import React from 'react';

function Question({ data, handleAnswer }) {
  return (
    <div className="bg-white p-8 rounded-lg shadow-md">
      <h2 className="text-xl">{data.questionText}</h2>
      <div className="mt-4">
        {data.options.map((option, index) => (
          <button
            key={index}
            className="block text-white bg-blue-500 hover:bg-blue-700 p-2 rounded mt-2"
            onClick={() => handleAnswer(option)}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

export default Question;
